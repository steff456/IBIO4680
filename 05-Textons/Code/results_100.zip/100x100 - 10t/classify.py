import numpy as np
from sklearn import neighbors, datasets
from sklearn.ensemble import RandomForestClassifier

route_map_tex = 'map_textons.npy'
route_texton_rep = 'texton_representation.npy'

map, textons = np.load(route_map_tex, encoding='latin1')
train_texton, test_texton = np.load(route_texton_rep, encoding = 'latin1')

def histc(X, bins):
    map_to_bins = np.digitize(X,bins)
    r = np.zeros(bins.shape)
    for i in map_to_bins:
        r[i-1] += 1
    return np.array(r)

#Number of clusters
k = 50

#Data = histogram from train data
train_data = []
#Labels of the train data
train_labels = []

for key in train_texton.keys():
    l = train_texton[key]
    for i in range(0,len(l)):
        if i == 0:
            m_act = l[i]
        else:
            m_act = l[i][0]
        act_hist = histc(m_act.flatten(), np.arange(k))/m_act.size
        train_data.append(act_hist)
        train_labels.append(key)

#Data = histogram from test data
test_data = []
#Labels of the test data
test_labels = []

for key in test_texton.keys():
    l = test_texton[key]
    for i in range(0,len(l)):
        if i == 0:
            m_act = l[i]
        else:
            m_act = l[i][0]
        act_hist = histc(m_act.flatten(), np.arange(k))/m_act.size
        test_data.append(act_hist)
        test_labels.append(key)

    #Create KN classifier
    knn=neighbors.KNeighborsClassifier()
    #Fit with training data
    knn.fit(train_data, train_labels)
    #Predict the test data
    res = knn.predict(test_data)

    count = 0
    for i in range(0,len(test_labels)):
        print(test_labels[i])
        print(res[i])
        print('-------')
        if test_labels[i] == res[i]:
            count +=1

    porcentage = (count/len(test_labels))*100
    print(str(porcentage) + '%')